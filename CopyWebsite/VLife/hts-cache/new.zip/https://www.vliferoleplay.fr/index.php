<!DOCTYPE html>

<html lang="fr">

	<head>
	  <meta charset="utf-8">
	  <meta content="width=device-width, initial-scale=1.0" name="viewport">
	<meta name="copyrighted-site-verification" content="19a03e9b2956baff" />

	  <title>vLife Roleplay</title>
	   <meta content="Serveur de jeu GTA V PC axé sur les
services de secours français." name="description">
	  <meta content="vlife roleplay boutique, boutique vlife, v-life rp boutique, vlife rp boutique,v-life roleplay, v-life gmod, v-life, vlife-roleplay, gmod, vlife gmod, vlife gta v, gta v, gta rp, vliferoleplay, vlife fivem, vlife, vlife rp, vlife-rp, v-life rp, vlife roleplay" name="keywords">
	  <meta property="og:locale" content="fr_FR">
<meta property="og:type" content="website">
<meta property="og:title" content="Communauté vLife Roleplay">
<meta property="og:description" content="Serveur de jeu GTA V PC axé sur les
services de secours français.">
<meta property="og:url" content="http://vliferoleplay.fr/">
<meta property="og:site_name" content="vLife Roleplay">
<meta property="og:image" content="https://cdn.vliferoleplay.fr/logo/favicon.png">
	  <meta name="google-site-verification" content="WFSp5XR_4u1pVnEdqWJf7eQnw-NvDCPG3gwn41zBX7o" />
	  	  <!-- Favicons -->
			<link rel="apple-touch-icon" sizes="180x180" href="https://www.vliferoleplay.fr/assets/img/favicon/apple-touch-icon.png">
			<link rel="icon" type="image/png" sizes="32x32" href="https://www.vliferoleplay.fr/assets/img/favicon/favicon-32x32.png">
			<link rel="icon" type="image/png" sizes="16x16" href="https://www.vliferoleplay.fr/assets/img/favicon/favicon-16x16.png">
			<link rel="manifest" href="https://www.vliferoleplay.fr/assets/img/favicon/site.webmanifest">
			<link rel="mask-icon" href="https://www.vliferoleplay.fr/assets/img/favicon/safari-pinned-tab.svg" color="#5bbad5">
			<link rel="shortcut icon" href="https://www.vliferoleplay.fr/assets/img/favicon/favicon.ico">
			<meta name="msapplication-TileColor" content="#2b5797">
			<meta name="msapplication-config" content="https://www.vliferoleplay.fr/assets/img/favicon/browserconfig.xml">
			<meta name="theme-color" content="#ffffff">
		  <!-- Google Fonts -->
	  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Jost:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

	  <!-- Vendor CSS Files 
	   <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
	  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
	  -->
	  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	 <!-- <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">-->
	   <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
	  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
	  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
	   <!-- <link rel="stylesheet" href="assets/vendor/font-awesome/css/all.min.css">Font Awesome 5.12.1 Pro -->

	  <!-- Template Main CSS File -->
	  <link href="assets/css/style.css" rel="stylesheet">
	  <link rel="stylesheet" href="assets/css/cookiealert.css">
	
		
	</head>

	<body>
	<div id="preloader"></div>


		<!DOCTYPE html>
<html lang="fr">
<style>
</style>
<body>
	<!--<div class="row ml-auto pull-right" style="margin-top:60px;position:absolute; top: 10px !important; right: 25px !important;">
		<div class="alert-group" style="width:100%">
            <div class="alert alert-info alert-dismissable" style="border-left: 4px solid #38a8bb;">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <strong>Campagne exceptionnelle - Mission humanitaire <a href="https://cagnotte-nicolas.fr/" target="_blank">https://cagnotte-nicolas.fr/</a>.</strong>
            </div>
       	  </div>
	</div>-->
	<!-- ======= Header ======= -->
	  <header id="header" class="fixed-top ">
<div class="container d-flex align-items-center">
		<a href="index.php" class="mr-auto">
		<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 224.56 98.54"><defs><style>.cls-1{fill:#fff;}</style></defs><g id="Calque_2" data-name="Calque 2"><g id="Calque_1-2" data-name="Calque 1"><polygon class="cls-1" points="61.81 0 61.81 58.08 102.66 58.08 102.66 46.8 75.35 46.8 75.35 0 61.81 0"/><rect class="cls-1" x="108.94" width="14.26" height="58.08"/><path class="cls-1" d="M129.48,0H172.8V12.56H143.41v9.59h27.08V34H143.41v24H129.48Z"/><polygon class="cls-1" points="179.08 0 222.41 0 222.41 12.56 193.01 12.56 193.01 22.15 220.09 22.15 220.09 34.02 193.01 34.02 193.01 45.64 222.41 45.64 222.41 58.08 179.08 58.08 179.08 0"/><path class="cls-1" d="M66,84.44a13.74,13.74,0,0,1-1.1,5.49,14.14,14.14,0,0,1-3,4.47,14.37,14.37,0,0,1-4.49,3,13.92,13.92,0,0,1-10.94,0,14.37,14.37,0,0,1-4.49-3,14.14,14.14,0,0,1-3-4.47,14.28,14.28,0,0,1,0-11,14.24,14.24,0,0,1,7.52-7.51,14.15,14.15,0,0,1,10.94,0,14.24,14.24,0,0,1,7.52,7.51A13.75,13.75,0,0,1,66,84.44Zm-4.38,0a9.94,9.94,0,0,0-2.86-7,10,10,0,0,0-3.09-2.14,9.24,9.24,0,0,0-7.52,0,10,10,0,0,0-5.18,5.28,9.77,9.77,0,0,0-.77,3.85,9.63,9.63,0,0,0,.77,3.8A10.34,10.34,0,0,0,45,91.41a10,10,0,0,0,3.09,2.15,9.31,9.31,0,0,0,7.55,0,9.87,9.87,0,0,0,3.08-2.15,10.47,10.47,0,0,0,2.07-3.17A9.63,9.63,0,0,0,61.58,84.44Z"/><path class="cls-1" d="M90.09,98H72.42V70.83h4.39v23H90.09Z"/><path class="cls-1" d="M143.91,79.59a8.72,8.72,0,0,1-.68,3.41,8.88,8.88,0,0,1-1.85,2.79,8.74,8.74,0,0,1-2.76,1.89,8.11,8.11,0,0,1-3.35.7h-8.6v9.69h-4.35V70.8h13a8.11,8.11,0,0,1,3.35.7,8.75,8.75,0,0,1,4.61,4.68A8.72,8.72,0,0,1,143.91,79.59Zm-4.42,0a4.43,4.43,0,0,0-.36-1.76,4.38,4.38,0,0,0-1-1.47,4.46,4.46,0,0,0-1.42-1A4.13,4.13,0,0,0,135,75h-8.33V84.2h8.26a4.47,4.47,0,0,0,1.79-.36,4.28,4.28,0,0,0,1.44-1,4.55,4.55,0,0,0,1-1.46A4.5,4.5,0,0,0,139.49,79.59Z"/><path class="cls-1" d="M169.68,98H149.35V70.83h4.39v23h15.94Z"/><path class="cls-1" d="M200,98h-4.66l-3.19-7.2H179.75l-3.2,7.2h-4.66L184,70.83h3.95Zm-9.72-11.39-4.36-9.79-4.31,9.79Z"/><path class="cls-1" d="M224.56,70.83,213.1,86.54V98h-4.32V86.54L197.29,70.83h5.27l8.36,11.46,8.44-11.46Z"/><path class="cls-1" d="M26.76,87a8.21,8.21,0,0,0,3.55-3.14,9.42,9.42,0,0,0,1-2.19,8.21,8.21,0,0,0,.36-2.4A8.33,8.33,0,0,0,31,76a8.62,8.62,0,0,0-1.77-2.69,8.48,8.48,0,0,0-2.63-1.84,7.8,7.8,0,0,0-3.21-.68H10.17v5.94h4.35V75h8.54a4,4,0,0,1,1.61.34,4.35,4.35,0,0,1,1.34.93,4.29,4.29,0,0,1,.9,1.37,4.24,4.24,0,0,1,.33,1.66A4.34,4.34,0,0,1,26.91,81a3.89,3.89,0,0,1-.9,1.37,4.3,4.3,0,0,1-1.36.92,4.2,4.2,0,0,1-1.66.33H14.52V79.17H10.17v18.9h4.35V87.77h7.55L28.87,98H34Z"/><polygon class="cls-1" points="100.22 86.37 114.81 86.37 114.81 82.19 100.22 82.19 100.22 79.17 95.87 79.17 95.87 98.03 116.54 98.03 116.54 93.85 100.22 93.85 100.22 86.37"/><polygon class="cls-1" points="95.87 70.8 95.87 76.74 100.22 76.74 100.22 74.98 116.54 74.98 116.54 70.8 95.87 70.8"/><path class="cls-1" d="M15.29,4.9c-.63-1.79-1.21-3.46-1.72-4.9H0C.45,1.4,1,3.06,1.56,4.9Z"/><path class="cls-1" d="M38.4,0l-12,36.61L16.76,9.09H2.89C8.39,26.4,17.16,54,18.47,58.08H34.32L52.87,0Z"/></g></g></svg>
		<!--<img src="https://cdn.vliferoleplay.fr/logo/logo_white.svg" alt="vLife RP" style="width: 110px;">-->
		</a>
		  <!--<h1 class="logo mr-auto"><a href="index.php">vLife RP</a></h1>
		  <!-- Uncomment below if you prefer to use an image logo -->
		  <!-- <a href="index.html" class="logo mr-auto"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
						
			
		  <nav class="nav-menu d-none d-lg-block">
			<ul>
			  <li class="active nav"><a href="#hero">Accueil</a></li>
			  <li class="dropdown"><a href="#"  class="dropdown-toggle" id="recrutement" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span>Recrutement</span> </a>
            <ul class="dropdown-menu" class="color:black" aria-labelledby="recrutement">
              <li><a class="dropdown-item" href="recrutement/"><i class="fas fa-file-signature fa-fw"></i> Rejoindre le serveur</a></li>
              <li><a class="dropdown-item" href ="#" data-toggle="modal" data-target="#Pole"><i class="fas fa-tools fa-fw"></i> Rejoindre le pôle technique</a></li>
              <li><a class="dropdown-item" href ="#" data-toggle="modal" data-target="#Fonction"><i class="fas fa-file-search fa-fw"></i> Fonctionnement</a></li>
              <li><a class="dropdown-item" class="dropdown-item" href ="#" data-toggle="modal" data-target="#FAQ"><i class="fas fa-question fa-fw"></i> Foire aux questions</a></li>
            </ul>
          </li>
		  
		  
		  <li class="dropdown"><a href="#"  class="dropdown-toggle" id="communication" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span>Communication</span> </a>
            <ul class="dropdown-menu" class="color:black" aria-labelledby="communication">
              <li><a class="dropdown-item" href="https://www.twitch.tv/vliferoleplay" target="_blank"><i class="fab fa-twitch fa-fw"></i> Twitch</a></li>
              <li><a class="dropdown-item" href="#portfolio"><i class="fas fa-image fa-fw"></i> Portfolio</a></li>
              <li><a class="dropdown-item" href ="https://twitter.com/vLifeRoleplay"  target="_blank"><i class="fab fa-twitter fa-fw"></i> Twitter</a></li>
			  <li><a  class="dropdown-item" href="partenaire.php"><i class="fas fa-handshake fa-fw"></i> Partenaires</a></li>
            </ul>
          </li>
		  
		   <li class="dropdown"><a href="#"  class="dropdown-toggle" id="communaute" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span>Communauté</span></a>
            <ul class="dropdown-menu" class="color:black" aria-labelledby="communaute">
              <li><a class="dropdown-item"  href="https://discord.gg/vliferp" target="_blank"><i class="fab fa-discord fa-fw"></i> Discord</a></li>
              <li><a class="dropdown-item" href="#team"><i class="fas fa-users-cog fa-fw"></i> Team</a></li>
	    <li><a class="dropdown-item" href="https://dons.vliferoleplay.fr/"><i class="fab fa-paypal fa-fw"></i>Donations</a></li>
			      			  
            </ul>
          </li>
			  <!--<li class="nav"><a href="partenaire.php">Partenaires</a></li>-->
			  <li class="nav"><a href="https://boutique.vliferoleplay.fr">Boutique</a></li>
			</ul>
			</nav>
		  <!-- .nav-menu -->
			<a href="?action=login" class="get-started-btn scrollto">Connexion</a>			
		</div>
		
	  </header><!-- End Header -->
	  <div class="modal fade faq" id="FAQ" tabindex="-1" role="dialog" aria-labelledby="FAQLabel" aria-hidden="false">
				  <div class="modal-dialog" role="document">
					<div class="modal-content">
					  <div class="modal-header">
						<h5 class="modal-title" id="FAQLabel">Foire aux questions</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						  <span aria-hidden="true">&times;</span>
						</button>
					  </div>
					  <div class="modal-body">
						<div class="section-title">
			  <h2 style="color:black;">Les questions souvent posées</h2>
			  <p>Vous trouverez ici plusieurs réponses à vos questions concernant le recrutement. Si malgré tout vous nécessitez une assistance, merci de passer par le discord, ou à défaut le formulaire de contact.</p>
			</div>

			<div class="faq-list" style="padding:0px;">
			  <ul>
				<li data-aos="fade-up" data-aos-delay="100">
				  <i class="fal fa-question-circle icon-help"></i> <a data-toggle="collapse" class="collapse" href="#faq-list-1"> Quel est le délai de réponse suite à une candidature ? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
				  <div id="faq-list-1" class="collapse show" data-parent=".faq-list">
					<p>
					  Il est de 48h, sauf période festive où il peut être plus long. 
					</p>
				  </div>
				</li>

				<li data-aos="fade-up" data-aos-delay="200">
				  <i class="fal fa-question-circle icon-help"></i> <a data-toggle="collapse" href="#faq-list-2" class="collapsed">Quel est l'âge minimum d'entrée ?<i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
				  <div id="faq-list-2" class="collapse" data-parent=".faq-list">
					<p>
					  L'âge minimal d'entrée pour le poste de civil est de 15 ans. 
					  Il est de 16 ans pour les services de secours, il n'y a aucune dérogation possible.
					</p>
				  </div>
				</li>

				<li data-aos="fade-up" data-aos-delay="300">
				  <i class="fal fa-question-circle icon-help"></i> <a data-toggle="collapse" href="#faq-list-3" class="collapsed"> L'expérience RP est-elle un critère d'évaluation important ?<i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
				  <div id="faq-list-3" class="collapse" data-parent=".faq-list">
					<p>
					  Non. Même si vous n'avez pas d'expérience, cela ne pénalisera en rien votre candidature.
					</p>
				  </div>
				</li>

				<li data-aos="fade-up" data-aos-delay="400">
				  <i class="fal fa-question-circle icon-help"></i> <a data-toggle="collapse" href="#faq-list-4" class="collapsed">Si je suis professionnel du métier, serais-je favorisé ? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
				  <div id="faq-list-4" class="collapse" data-parent=".faq-list">
					<p>
					  En aucun cas, nous privilégions l'équité entre les candidats, qu'importe votre statut, âge ou métier.
					</p>
				  </div>
				</li>
				<li data-aos="fade-up" data-aos-delay="500">
				  <i class="fal fa-question-circle icon-help"></i> <a data-toggle="collapse" href="#faq-list-5" class="collapsed">J'ai postulé pour un service de secours et je souhaiterais devenir Civil, en attendant d'avoir ma réponse, est-ce possible ? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
				  <div id="faq-list-5" class="collapse" data-parent=".faq-list">
					<p>
					  Cela n'est en aucun cas possible. Veuillez prendre votre mal en patience.
					</p>
				  </div>
				</li>
				
				<li data-aos="fade-up" data-aos-delay="600">
				  <i class="fal fa-question-circle icon-help"></i> <a data-toggle="collapse" href="#faq-list-6" class="collapsed">Si je suis refusé à l'écris ou à l'oral que dois-je faire ? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
				  <div id="faq-list-6" class="collapse" data-parent=".faq-list">
					<p>
					  En dehors d'un refus définitif ou d'un bannissement vous avez la possibilité de déposer une seconde candidature deux semaines après la date de votre refus. 
					  Le deuxième refus sera cependant définitif
					</p>
				  </div>
				</li>

			  </ul>
			</div>
					  </div>
					  <div class="modal-footer">
						<button type="button" class="btn btn-primary" data-dismiss="modal">Fermer</button>
					  </div>
					</div>
				  </div>
				</div>
			<div class="modal fade" id="Fonction" tabindex="-1" role="dialog" aria-labelledby="FonctionLabel" aria-hidden="false">
				<div class="modal-dialog" role="document">
					<div class="modal-content">
					  <div class="modal-header">
						<h5 class="modal-title" id="FonctionLabel">Fonctionnement</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						  <span aria-hidden="true">&times;</span>
						</button>
					  </div>
					<div class="modal-body">
						<div class="section-title">
						  <h2 style="color:black;">Fonctionnement du serveur</h2>
						  <p>Vous trouverez ici le fonctionnement du serveur se trouvant à la limite du life et du totalement scénarisé.</p>
						</div>
						<div  style="padding:0px;">
						<p style="white-space:pre-line;overflow:auto;">Nous fonctionnons par session de jeu définie, le roleplay n'est pas constant pour pouvoir tous se réunir aux heures de jeu. 
						Chaque session débute à 21h00 et n'a pas d'heure de fin (jusqu'à que l'ensemble des joueurs déconnectent). Ces sessions RP sont réalisées tous les jours.
						Les actions doivent impliquer les services de secours, de temps en temps encadré par des plus anciens. On parle ici d'accompagnement pour un jeune joueur sur notre serveur, qu'il ne soit pas perdu. Cela demande aussi de la coordination, pour que chaque intervention soient réalisées au bon moment, et que tout le monde en profite (pas de temps mort)
						Vu que les actions sont créées par les civils, elles peuvent être non spontanées (montée de toute pièce), c'est de l'action passive.
						Néanmoins, les services de secours ne sont pas au courant de ce qui se déroule, et l'ensemble des manœuvres faites par les secours ne sont pas connues ni préparées, tout doit être géré par le pompier/policier/médecin qui doit mettre en pratique ce qu'il a pu apprendre en formation.
						À savoir que la vie civile perdure constamment, chaque interventions peuvent avoir un lien entre elles.</p>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-primary" data-dismiss="modal">Fermer</button>
					</div>
					</div>
				</div>
			</div>
			
			<div class="modal fade" id="Pole" tabindex="-1" role="dialog" aria-labelledby="polet" aria-hidden="false">
				<div class="modal-dialog" role="document">
					<div class="modal-content">
					  <div class="modal-header">
						<h5 class="modal-title" id="polet">Rejoindre le pôle technique</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						  <span aria-hidden="true">&times;</span>
						</button>
					  </div>
					<div class="modal-body">
						<div class="section-title">
						  <h2 style="color:black;">Rejoindre le pôle technique</h2>
						  <p>Si vous souhaitez rejoindre notre pôle technique, merci de suivre les indications suivantes :</p>
						</div>
						<div  style="padding:0px;">
						<a style="cursor: zoom-in;" href="https://cdn.discordapp.com/attachments/568461477405655081/827879638277554203/2021-03-28_5.png" data-gall="Gall" class="venobox preview-link" title="Agrandir"><img loading="lazy" class="img-fluid" src="https://cdn.discordapp.com/attachments/568461477405655081/827879638277554203/2021-03-28_5.png" alt="Rejoindre pôle technique"></a>
						<p style="white-space:pre-line;overflow:auto;">
						Vous pouvez également contacter tout membre de l'<img class="img-fluid" loading="lazy" src="https://cdn.discordapp.com/attachments/432167703453761537/912613854423420928/unknown.png" width="20%" alt="état-major"></img> via notre <a href="https://discord.gg/vliferp" target="_blank"><i style="font-size:20px;" class="fab fa-discord"></i></a>
						</p>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-primary" data-dismiss="modal">Fermer</button>
					</div>
					</div>
				</div>
			</div>
			
			
	</body>
</html>

	  <!-- ======= Hero Section ======= -->
	  <section id="hero" class="d-flex align-items-center hero">

		<div class="container">
		  <div class="row">

			<div class="col-lg-6 d-flex flex-column justify-content-center pt-4 pt-lg-0 order-2 order-lg-1" data-aos="fade-up" data-aos-delay="200">
			  <h1>Serveur vLife Roleplay</h1>
			  <h2>Serveur GTA V de services de secours<br>
			  <i><small>Nos actions se déroulent dans le cadre de la simulation</small></i></h2>
			   
			  <div class="d-lg-flex">
				<a href="recrutement/" class="btn-get-started scrollto">Nous rejoindre</a>
				<a href="https://www.youtube.com/watch?v=80eNQApSxQM" class="venobox btn-watch-video" data-vbtype="video" data-autoplay="true"> Regarder la vidéo <i class="fal fa-play-circle" style="display:flex;"></i></a>
			  	<!--<div class="talk-bubble triangle left-top">
  					<div class="talktext">
    						<p>Nouveau</p>
  					</div>
				</div>-->
			  </div>
			</div>
			<div class="col-lg-6 order-1 order-lg-2 hero-img" data-aos="zoom-in" data-aos-delay="200">
			  <img src="assets/img/hero-img.webp" class="img-fluid animated" alt="">
			</div>
		  </div>
		</div>
	  </section><!-- End Hero -->

	  <main id="main">

		<!-- ======= Cliens Section ======= -->
		<section class="cliens section-bg">
		  <div class="container">

			<div class="row" data-aos="zoom-in">

			  <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
				<a href="https://fivem.net/ " target="_blank">
				<img src="assets/img/clients/client-1.png" class="img-fluid" alt="">
				</a>
			  </div>
			  
			  <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
				<a href="https://brocloud.fr" target="_blank">
				<img src="https://cdn.discordapp.com/attachments/432167703453761537/1049134867566317588/brocloud_white.png" class="img-fluid" alt="">
				</a>
			  </div>

			  <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
				<a href="https://www.saltmine.de/" target="_blank">
				<img src="assets/img/clients/client-3.png" class="img-fluid" alt="">
				</a>
			  </div>
			   <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
				<a href ="https://discord.gg/m7JuqpYqVj" target="_blank"> 
				<img  src="assets/img/clients/client-8.png" class="img-fluid" alt="">
				</a>
			  </div>

			  <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
				<a href ="https://rytrak.fr/" target="_blank">
				<img src="https://cdn.discordapp.com/attachments/732292608193331290/949056385621041172/faviconwhite.png" class="img-fluid" alt="">
				</a>
			  </div>

			  <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
				<a href ="https://discord.gg/mkQsmHf5pw" target="_blank">
				<img  src="assets/img/clients/client-6.png" class="img-fluid" alt="">
				</a>
			  </div>
					

			</div>

		  </div>
		</section><!-- End Cliens Section -->

		<!-- ======= About Us Section ======= -->
		<section id="about" class="about">
		  <div class="container" data-aos="fade-up">

			<div class="section-title">
			  <h2>Présentation</h2>
			</div>

			<div class="row content">
			  <div class="col-lg-6">
				<p>
				  L'organisation vLife est un serveur de jeu GTA V PC axé sur les services de secours français.
				</p>
				<ul>
				  <li><i class="fal fa-check-double"></i> Rempli de passionnés et de professionnels du métier</li>
				  <li><i class="fal fa-check-double"></i> Approche du roleplay différente et enrichissante.</li>
				  <li><i class="fal fa-check-double"></i> Discipline, respect et rigueur vous accompagneront.</li>
				</ul>
			  </div>
			  <div class="col-lg-6 pt-4 pt-lg-0">
				<p>
				  Nous avons été crée en mars 2019, nous avons pour but de rassembler toutes personnes intéressées par les services de secours. 
				  Nous étions à la base sur GMOD, voyant nos capacités être limitées, nous avons rapidement évolué vers GTA V. 
				  Toujours en continuant à offrir plus de contenus et dans le confort d'une communauté toujours plus grandissante.
				</p>
				<!--<a href="#" class="btn-learn-more">Learn More</a> -->
			  </div>
			</div>

		  </div>
		</section><!-- End About Us Section -->
				<!-- ======= Services Section ======= -->
		<section id="services" class="services section-bg">
		  <div class="container" data-aos="fade-up">

			<div class="section-title">
			  <h2>Caractéristiques</h2>
			  <p>Ce que nous proposons au sein de la communauté vLife RP.</p>
			</div>

			<div class="row">
			  <div class="col-xl-3 col-md-6 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="100">
				<div class="icon-box">
				  <div class="icon"><i class="fal fa-basketball-ball"></i></div>
				  <h4><a href="#services">Communautaire</a></h4>
				  <p>Nous sommes avant tout un serveur communautaire, basé sur l'entraide et totalement gratuit.</p>
				</div>
			   </div>
			<!--
			# Autre design : 
			<div data-aos="zoom-in" data-aos-delay="100" class="col-xl-3 col-md-2 aos-init aos-animate" style="padding-right: 15px;">
				<div class="icon-box" style="padding-right: 10px;border-right-width: 0px;border-right-style: solid;padding-bottom: 10px;padding-top: 10px;padding-left: 10px;border-top: 3px solid #47b2e442;border-bottom: 3px solid #47b2e442;">
					
					<figurine class="icon" style=""> <i class="bx bxl-dribbble" style="color;background: #334bac45;border-radius:10px;font-size:25px"></i></figurine>
				  <a href="#services" style="font-size: 20px;padding-top: 0px;padding-right: 0px;border-bottom-style: solid;border-bottom-width: 0px;vertical-align: super;">Communautaire</a>
				  
				  <p>Nous sommes avant tout un serveur communautaire, à l'écoute de vos retours et demandes.</p>
				</div>
			  </div>-->

			  <div class="col-xl-3 col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="zoom-in" data-aos-delay="200">
				<div class="icon-box">
				  <div class="icon"><i class="fal fa-file-code"></i></div>
				  <h4><a href="#services">Mods uniques</a></h4>
				  <p>Nous avons en notre possession plusieurs mods et véhicules uniques au serveur.</p>
				 
				</div>
			  </div>

			  <div class="col-xl-3 col-md-6 d-flex align-items-stretch mt-4 mt-xl-0" data-aos="zoom-in" data-aos-delay="300">
				<div class="icon-box">
				  <div class="icon"><i class="fal fa-tachometer-fastest"></i></div>
				  <h4><a href="#services">Performance</a></h4>
				  <p>Nous avons un serveur performant, compléter par un système de ticket. </p>
				</div>
			  </div>

			  <div class="col-xl-3 col-md-6 d-flex align-items-stretch mt-4 mt-xl-0" data-aos="zoom-in" data-aos-delay="400">
				<div class="icon-box">
				  <div class="icon"><i class="fal fa-layer-group"></i></div>
				  <h4><a href="#services">Professionnalisme</a></h4>
				  <p>Support de transmission et partage de connaissances entre professionnels et passionnés. </p>
				</div>
			  </div>

			</div>

		  </div>
		</section><!-- End Services Section -->

		<!-- ======= Don Section ======= -->
		<section id="don" class="cta">
		  <div class="container" data-aos="zoom-in">

			<div class="row">
			  <div class="col-lg-9 text-center text-lg-left">
				<h3>Nous soutenir ?</h3>
				<p>Notre serveur est totalement basé sur la gratuité. Si vous souhaitez nous soutenir, il vous est possible de nous faire une donation. Tout montant est le bienvenue.</p>
			  </div>
			  <div class="col-lg-3 cta-btn-container text-center">
				<a class="cta-btn align-middle" target="_blank"href="https://dons.vliferoleplay.fr/">Donation</a>
			  </div>
			</div>

		  </div>
		</section>
		<!-- End Don Section -->

		<!-- ======= Portfolio Section ======= -->
		<section id="portfolio" class="portfolio">
		  <div class="container" data-aos="fade-up">

			<div class="section-title">
			  <h2>Portfolio</h2>
			  <p>Le serveur est constitué de plusieurs services de secours, dont la Police, les Sapeurs-Pompiers et le S.A.M.U.</p>
			</div>

			<ul id="portfolio-flters" class="d-flex justify-content-center" data-aos="fade-up" data-aos-delay="100">
			  <li data-filter="*" class="filter-active">Tout</li>
			  <li data-filter=".filter-app">Pompier</li>
			  <li data-filter=".filter-card">Police</li>
			  <li data-filter=".filter-web">SAMU</li>
			</ul>

			<div class="row portfolio-container" style="height:681px;" data-aos="fade-up" data-aos-delay="200">

			  <div class="col-lg-4 col-md-6 portfolio-item filter-app">
				<div class="portfolio-img"><img loading="lazy" src="assets/img/portfolio/portfolio-4.jpg"  class="img-fluid" alt=""></div>
				<div class="portfolio-info">
				  <h4>Pompier 1</h4>
				  <p>Pompier</p>
				  <a href="assets/img/portfolio/portfolio-4.png" data-gall="portfolioGallery" class="venobox preview-link" title="Agrandir"><i class="fal fa-plus"></i></a>
				  <a href="assets/img/portfolio/portfolio-4.png" download="Pompier 1 - vLife" class="details-link" title="Télécharger"><i class="fal fa-download"></i></a>
				</div>
			  </div>

			  <div class="col-lg-4 col-md-6 portfolio-item filter-web">
				<div class="portfolio-img"><img loading="lazy" src="assets/img/portfolio/portfolio-7.jpg" class="img-fluid" alt=""></div>
				<div class="portfolio-info">
				  <h4>SAMU 1</h4>
				  <p>SAMU</p>
				  <a href="assets/img/portfolio/portfolio-7.png" data-gall="portfolioGallery" class="venobox preview-link" title="Agrandir"><i class="fal fa-plus"></i></a>
				  <a href="assets/img/portfolio/portfolio-7.png" download="SAMU 1 - vLife" class="details-link" title="Télécharger"><i class="fal fa-download"></i></a>
				</div>
			  </div>

			  <div class="col-lg-4 col-md-6 portfolio-item filter-app">
				<div class="portfolio-img"><img loading="lazy" src="assets/img/portfolio/portfolio-5.jpg" class="img-fluid" alt=""></div>
				<div class="portfolio-info">
				  <h4>Pompier 2</h4>
				  <p>Pompier</p>
				  <a href="assets/img/portfolio/portfolio-5.png" data-gall="portfolioGallery" class="venobox preview-link" title="Agrandir"><i class="fal fa-plus"></i></a>
				  <a href="assets/img/portfolio/portfolio-5.png" download = "Pompier 2 - vLife"class="details-link" title="Télécharger"><i class="fal fa-download"></i></a>
				</div>
			  </div>

			  <div class="col-lg-4 col-md-6 portfolio-item filter-card">
				<div class="portfolio-img"><img loading="lazy" src="assets/img/portfolio/portfolio-1.jpg" class="img-fluid" alt=""></div>
				<div class="portfolio-info">
				  <h4>Police 1</h4>
				  <p>Police</p>
				  <a href="assets/img/portfolio/portfolio-1.png" data-gall="portfolioGallery" class="venobox preview-link" title="Agrandir"><i class="fal fa-plus"></i></a>
				  <a href="assets/img/portfolio/portfolio-1.png" download="Police 1 - vLife"class="details-link" title="Télécharger"><i class="fal fa-download"></i></a>
				</div>
			  </div>

			  <div class="col-lg-4 col-md-6 portfolio-item filter-web">
				<div class="portfolio-img"><img loading="lazy" src="assets/img/portfolio/portfolio-8.jpg" class="img-fluid" alt=""></div>
				<div class="portfolio-info">
				  <h4>SAMU 2</h4>
				  <p>SAMU</p>
				  <a href="assets/img/portfolio/portfolio-8.png" data-gall="portfolioGallery" class="venobox preview-link" title="Agrandir"><i class="fal fa-plus"></i></a>
				  <a href="assets/img/portfolio/portfolio-8.png" download="SAMU 2 - vLife" class="details-link" title="Télécharger"><i class="fal fa-download"></i></a>
				</div>
			  </div>

			  <div class="col-lg-4 col-md-6 portfolio-item filter-app">
				<div class="portfolio-img"><img loading="lazy" src="assets/img/portfolio/portfolio-6.jpg" class="img-fluid" alt=""></div>
				<div class="portfolio-info">
				  <h4>Pompier 3</h4>
				  <p>Pompier</p>
				  <a href="assets/img/portfolio/portfolio-6.png" data-gall="portfolioGallery" class="venobox preview-link" title="Agrandir"><i class="fal fa-plus"></i></a>
				  <a href="assets/img/portfolio/portfolio-6.png" download ="Pompier 3 - vLife" class="details-link" title="Télécharger"><i class="fal fa-download"></i></a>
				</div>
			  </div>

			  <div class="col-lg-4 col-md-6 portfolio-item filter-card">
				<div class="portfolio-img"><img loading="lazy" src="assets/img/portfolio/portfolio-2.jpg" class="img-fluid" alt=""></div>
				<div class="portfolio-info">
				  <h4>Police 2</h4>
				  <p>Police</p>
				  <a href="assets/img/portfolio/portfolio-2.png" data-gall="portfolioGallery" class="venobox preview-link" title="Agrandir"><i class="fal fa-plus"></i></a>
				  <a href="assets/img/portfolio/portfolio-2.png" download ="Police 2 - vLife" class="details-link" title="Télécharger"><i class="fal fa-download"></i></a>
				</div>
			  </div>

			  <div class="col-lg-4 col-md-6 portfolio-item filter-card">
				<div class="portfolio-img"><img loading="lazy" src="assets/img/portfolio/portfolio-3.jpg" class="img-fluid" alt=""></div>
				<div class="portfolio-info">
				  <h4>Police 3</h4>
				  <p>Police</p>
				  <a href="assets/img/portfolio/portfolio-3.png" data-gall="portfolioGallery" class="venobox preview-link" title="Agrandir"><i class="fal fa-plus"></i></a>
				  <a href="assets/img/portfolio/portfolio-3.png" download="Police 3 - vLife" class="details-link" title="Télécharger"><i class="fal fa-download"></i></a>
				</div>
			  </div>

			  <div class="col-lg-4 col-md-6 portfolio-item filter-web">
				<div class="portfolio-img"><img loading="lazy" src="assets/img/portfolio/portfolio-9.jpg" class="img-fluid" alt=""></div>
				<div class="portfolio-info">
				  <h4>Samu 3</h4>
				  <p>Samu</p>
				  <a href="assets/img/portfolio/portfolio-9.png" data-gall="portfolioGallery" class="venobox preview-link" title="Agrandir"><i class="fal fa-plus"></i></a>
				  <a href="assets/img/portfolio/portfolio-9.png" download="Samu 3 - vLife" class="details-link" title="Télécharger"><i class="fal fa-download"></i></a>
				</div>
			  </div>

			</div>

		  </div>
		</section><!-- End Portfolio Section -->

		<!-- ======= Team Section ======= -->
		<section id="team" class="team section-bg">
		  <div class="container" data-aos="fade-up">
			
			<div class="section-title">
			  <h2>Team</h2>
			  <p>Voici une partie de notre team qui s'efforce toujours d'améliorer et pousser plus loin les limites du serveur.</p>
			</div>

			<div class="row blog">
				 <div class="col-md-12">
                    <div id="blogCarousel" class="carousel slide" data-ride="carousel">
				<ol class="carousel-indicators">
                            <li data-target="#blogCarousel" data-slide-to="0" class="active"></li>
                            <li data-target="#blogCarousel" data-slide-to="1"></li>
							<li data-target="#blogCarousel" data-slide-to="2"></li>
							<li data-target="#blogCarousel" data-slide-to="3"></li>
                        </ol>	
						
			<div class="carousel-inner">
			
			 <div class="carousel-item active">
                 <div class="row">
			  <div class="col-lg-6">
				<div class="member d-flex align-items-start" data-aos="zoom-in" data-aos-delay="100">
				  <div class="pic"><img loading="lazy" src="assets/img/team/team-1.webp" class="img-fluid" alt=""></div>
				  <div class="member-info">
					<h4 class="emajor">Brayan Vagler</h4>
					<span>CEO | Chef de Projet</span>
					<p>Fort de son expérience, il s'occupe de la coordination de l'ensemble du projet et du personnel.</p>
					<div class="social">
					  <a href="https://twitter.com/vLifeRoleplay" target="_blank"><i class="fab fa-twitter"></i></a>
					  <a href="https://www.youtube.com/channel/UCGIaj2gVvI2P49KcdKPHUJQ" target="_blank"><i class="fab fa-youtube"></i></a>
					  <a href="https://www.instagram.com/vliferoleplay/" target="_blank"><i class="fab fa-instagram"></i></a>
					  <a href="https://www.twitch.tv/vliferoleplay" target="_blank"><i class="fab fa-twitch"></i></a>
					</div>
				  </div>
				</div>
			  </div>

			  <div class="col-lg-6 mt-4 mt-lg-0">
				<div class="member d-flex align-items-start" data-aos="zoom-in" data-aos-delay="200">
				  <div class="pic"><img loading="lazy" src="assets/img/team/team-3.webp" class="img-fluid" alt=""></div>
				  <div class="member-info">
					<h4 class="emajor">Rytrak</h4>
					<span>Lead Pôle Technique</span>
					<p>Développeur et modélisateur au sein de notre serveur. C'est l'un des couteaux suisses de vLife.</p>
					<div class="social">
					  <a href="https://steamcommunity.com/id/rytrak" target="_blank"><i class="fab fa-steam-symbol"></i></a>
					   <a href="https://www.youtube.com/channel/UCsAbsoJdj0-yZAt-kQzK-PA" target="_blank"><i class="fab fa-youtube"></i></a>
					</div>
				  </div>
				</div>
			  </div>

			  <div class="col-lg-6 mt-4">
				<div class="member d-flex align-items-start" data-aos="zoom-in" data-aos-delay="300">
				  <div class="pic"><img loading="lazy" src="assets/img/team/team-5.webp" class="img-fluid" alt=""></div>
				  <div class="member-info">
					<h4 class="staff">Charles Bertier</h4>
					<span>Développeur logiciel</span>
					<p>Développe, héberge et assure la maintenance de logiciels pour le serveur.</p><br>
				  </div>
				</div>
			  </div>

			  <div class="col-lg-6 mt-4">
				<div class="member d-flex align-items-start" data-aos="zoom-in" data-aos-delay="400">
				    <div class="pic"><img loading="lazy" src="assets/img/team/team-6.webp" class="img-fluid" alt=""></div>
				  <div class="member-info">
					<h4 class="ptech">Guillaume Grivel</h4>
					<span>Moddeur</span>
					<p>Moddeur à plein temps sur notre serveur.</p>
				  </div>
				</div>
			  </div>

			</div>
			</div>
			
			<div class="carousel-item">
                 <div class="row">
			  <div class="col-lg-6">
				<div class="member d-flex align-items-start" data-aos="zoom-in" data-aos-delay="100">
				  <div class="pic"><img loading="lazy" src="assets/img/team/team-8.webp" class="img-fluid" alt=""></div>
				  <div class="member-info">
					<h4 class="ptech">W4nou</h4>
					<span>Modélisateur</span>
					<p>Modélisateur 3D sur le serveur vLife.</p>
					<div class="social">
					  <a href="https://steamcommunity.com/id/w4nou/" target="_blank"><i class="fab fa-steam-symbol"></i></a>
					   <a href="https://discord.gg/mkQsmHf5pw" target="_blank"><i class="fab fa-discord"></i></a>
					</div>
				  </div>
				</div>
			  </div>

			  
			  <div class="col-lg-6 mt-4 mt-lg-0">
				<div class="member d-flex align-items-start" data-aos="zoom-in" data-aos-delay="200">
				  	 <div class="pic"><img loading="lazy" src="assets/img/team/team-12.webp" class="img-fluid" alt=""></div>
				  <div class="member-info">
					<h4>Matthieu Hubert</h4>
					<span>Chef de service au SAMU 93 du serveur</span>
					<p>Passionné par les secours, il assure les fonctions de responsable administratif du service d'aide médicale urgente du serveur.</p><br>
				  </div>
				</div>
			  </div>

			  <div class="col-lg-6 mt-4">
				<div class="member d-flex align-items-start" data-aos="zoom-in" data-aos-delay="300">
				  
				 <div class="pic"><img loading="lazy" src="assets/img/team/team-4.webp" class="img-fluid" alt=""></div>
				  <div class="member-info">
					<h4 class="emajor">AuraAngel</h4>
					<span>Développeur web | <a class="tip" data-toggle="tooltip" data-placement="bottom" title="Directeur des Ressources Humaines">DRH</a> du serveur</span>
					<p>Développeur web de ce site et <a class="tip" data-toggle="tooltip" data-placement="bottom" title="Directeur des Ressources Humaines">DRH</a> du serveur.</p><br><br>
					</div>
				</div>
			  </div>

			  <div class="col-lg-6 mt-4">
				<div class="member d-flex align-items-start" data-aos="zoom-in" data-aos-delay="400">
				  <div class="pic"><img loading="lazy" src="assets/img/team/team-9.jpg" class="img-fluid" alt=""></div>
				  <div class="member-info">
					<h4 class="ptech">Kilian Dumas</h4>
					<span>Moddeur</span>
					<p>Moddeur sur le serveur vLife..</p>
				  </div>
				</div>
			  </div>

			</div>
			</div>
			
			<!-- New item -->
			
			
			<div class="carousel-item">
                 <div class="row">
			  <div class="col-lg-6">
				<div class="member d-flex align-items-start" data-aos="zoom-in" data-aos-delay="100">
				  
					<div class="pic"><img loading="lazy" src="assets/img/team/team-9.webp" class="img-fluid" alt=""></div>
				  <div class="member-info">
					<h4 class="staff">Pharrel Williams</h4>
					<span>Commissaire de Police - Chef de la circonscription d’Aulnay-Sous-Bois du serveur.</span>
					<p>Professionnel du métier, il gère l'ensemble de la circonscription du serveur.</p>
				</div>
				</div>
			  </div>

			  
			  <div class="col-lg-6 mt-4 mt-lg-0">
				<div class="member d-flex align-items-start" data-aos="zoom-in" data-aos-delay="200">
				  <div class="pic"><img loading="lazy" src="assets/img/team/team-10.webp" class="img-fluid" alt=""></div>
				  <div class="member-info">
					<h4 class="staff">Arnaud Duke</h4>
					<span>Commandant de Police - Adjoint au chef de service de la circonscription d’Aulnay-Sous-Bois du serveur</span>
					<p>Professionnel du métier depuis 10 ans dont plusieurs années en BAC, il aime partager sa passion de policier de terrain.</p><br>
				  </div>
				</div>
			  </div>
				
			 <!--<div class="col-lg-6 mt-4">
				<div style="background:none !important;box-shadow:none !important;" class="member d-flex align-items-start" data-aos="zoom-in" data-aos-delay="300">
				  <div class="pic"></div>
				  <div class="member-info">
				  </div>
				</div>
			  </div>!-->
			 <div class="col-lg-6 mt-4">
				<div class="member d-flex align-items-start" data-aos="zoom-in" data-aos-delay="300">
				  <div class="pic"><img loading="lazy" src="assets/img/team/team-11.webp" class="img-fluid" alt=""></div>
				  <div class="member-info">
					<h4>Florian Ruiz</h4>
					<span>Capitaine de Police et chef de la compagnie motocycliste du serveur</span>
					<p>Gendarme, futur OPJ, apprécie transmettre son savoir-faire et son expérience aux effectifs !</p><br>
				
				  </div>
				</div>
			  </div>
			  
			  <div class="col-lg-6 mt-4">
				<div class="member d-flex align-items-start" data-aos="zoom-in" data-aos-delay="400">
				  <div class="pic"><img loading="lazy" src="assets/img/team/team-12.png" class="img-fluid" alt=""></div>
				  <div class="member-info">
					<h4 class="staff">Numa Capdeville</h4>
					<span>Chef de la <a class="tip" data-toggle="tooltip" data-placement="bottom" title="Brigade Territoriale de Contact">BTC</a> de vLife</span>
					<p>Il s'occupe de la partie animation du serveur. Il assure également les fonctions de chef de la <a class="tip" data-toggle="tooltip" data-placement="bottom" title="Brigade Territoriale de Contact">BTC</a> de vLife</p><br>
				  </div>
				</div>
			  </div>
			</div>

			</div>
			
			
			<div class="carousel-item">
                 <div class="row">
			  <div class="col-lg-6">
				<div class="member d-flex align-items-start" data-aos="zoom-in" data-aos-delay="100">
				  
					<div class="pic"><img loading="lazy" src="assets/img/team/team-13.webp" class="img-fluid" alt=""></div>
				  <div class="member-info">
					<h4 class="staff">Kevin Morrisson</h4>
					<span>Caporal-Chef - Formateur chez les Pompiers de Paris du serveur.</span>
					<p>Passionné par le monde des Sapeurs-Pompiers . Il a pu en apprendre sur le monde de la Brigade des Sapeurs Pompiers de Paris.</p>
				  </div>
				</div>
			  </div>

			  
			  <div class="col-lg-6 mt-4 mt-lg-0">
				<div class="member d-flex align-items-start" data-aos="zoom-in" data-aos-delay="200">
				  <div class="pic"><img loading="lazy" src="assets/img/team/team-15.webp" class="img-fluid" alt=""></div>
				  <div class="member-info">
					<h4 class="ptech">Pingouin</h4>
					<span>Développeur</span>
					<p>Passionné d’algorithmique et programmation, il développe des scripts pour vLife</p>
				 	<div class="social">
					  <a href="https://www.pingouin.dev/" target="_blank"><i class="fal fa-link"></i></a>
					   <a href="https://discord.gg/Hf2G43ZY4S" target="_blank"><i class="fab fa-discord"></i></a>
					</div>  
				</div>
				</div>
			  </div>
			  
			  <div class="col-lg-6 mt-4">
				<div style="background:none !important;box-shadow:none !important;" class="member d-flex align-items-start" data-aos="zoom-in" data-aos-delay="300">
				  <div class="pic"></div>
				  <div class="member-info">
				  </div>
				</div>
			  </div>
				<div class="col-lg-6 mt-4">
				<div style="background:none !important;box-shadow:none !important;" class="member d-flex align-items-start" data-aos="zoom-in" data-aos-delay="300">
				  <div class="pic"></div>
				  <div class="member-info">
				  </div>
				</div>
			  </div>			  
			
			
			</div>
			
			</div>
			</div>
			
		
		
		  </div>
		  <div class="legend"> 
		  <p>Légende : Membres <a class="tip" data-toggle="tooltip" data-placement="bottom" title="Constitué des membres fondateurs ou administrateurs du serveur">État-Major</a> <i class="circle red"></i>
		  | Membres du <a class="tip" data-toggle="tooltip" data-placement="bottom" title="Constitué des membres du personnel du serveur, assistant l'état-major dans la prise de décision">Staff</a> <i class="circle orange"></i> 
		  | Membres <a class="tip" data-toggle="tooltip" data-placement="bottom" title="Constitué des moddeurs ou développeur du serveur">Pôle technique</a> <i class="circle yellow"></i></p></div></div>
		</section>
		<!-- End Team Section -->
		<!-- ======= Cta Section ======= -->
		<section id="cta" class="cta">
		  <div class="container" data-aos="zoom-in">

			<div class="row">
			  <div class="col-lg-9 text-center text-lg-left">
				<h3>Devenir Civil ?</h3>
				<p>Vous avez 15 ans et vous souhaitez tenter l'expérience vLife ? Mettez un pied dans le métier et jouez avec des professionnels et passionnés au sein de notre serveur GTAV !</p>
			  </div>
			  <div class="col-lg-3 cta-btn-container text-center">
				<a class="cta-btn align-middle" href="recrutement/">Nous rejoindre</a>
			  </div>
			</div>

		  </div>
		</section>
		<!-- End Cta Section -->
				<!-- ======= Contact Section ======= -->
		<section id="contact" class="contact">
		  <div class="container" data-aos="fade-up">

			<div class="section-title">
			  <h2>Contact</h2>
			  <p>Si vous êtes désireux de nous contacter, veuillez remplir le formulaire ci-dessous.
</p>
				<i>Tout contact abusif ne recevra aucune réponse, merci de votre compréhension</i>
			</div>

			<div class="row">

				<div class="col-lg-3 d-flex align-items-stretch">
			  <!--  <div class="info">
				  <div class="address">
					<i class="icofont-google-map"></i>
					<h4>Location:</h4>
					<p>A108 Adam Street, New York, NY 535022</p>
				  </div>

				  <div class="email">
					<i class="icofont-envelope"></i>
					<h4>Email:</h4>
					<p>info@example.com</p>
				  </div>

				  <div class="phone">
					<i class="icofont-phone"></i>
					<h4>Call:</h4>
					<p>+1 5589 55488 55s</p>
				  </div>

				  <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d12097.433213460943!2d-74.0062269!3d40.7101282!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xb89d1fe6bc499443!2sDowntown+Conference+Center!5e0!3m2!1smk!2sbg!4v1539943755621" frameborder="0" style="border:0; width: 100%; height: 290px;" allowfullscreen></iframe>
				</div>-->

			  </div>

			  <div class="col-lg-6 mt-5 mt-lg-0 d-flex align-items-stretch">
				<!--<form action="forms/contact.php" method="post" role="form" class="php-email-form">-->
				<form role="form" id="contactForm" action="forms/contact-process.php" data-toggle="validator" class="php-email-form">
				  <div class="form-row">
					<div class="form-group col-md-6">
					  <label for="name">Votre nom</label>
					  <input type="text" name="name" class="form-control" id="name" data-rule="minlen:4" data-msg="Merci d'entrer au moins 4 caractères." />
					  <div class="validate"></div>
					</div>
					<div class="form-group col-md-6">
					  <label for="name">Votre email</label>
					  <!--<input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">-->
					   <input type="email" class="form-control" name="email" id="email" data-rule="email" data-msg="Merci d'entrer un email" />					  <div class="validate"></div>
					</div>
				  </div>
				  <div class="form-group">
					<label for="name">Sujet</label>
					<input type="text" class="form-control" name="subject" id="subject" data-rule="minlen:4" data-msg="Merci d'entrer au moins 8 caractères" />
					<div class="validate"></div>
				  </div>
				  <div class="form-group">
					<label for="name">Message</label>
					<textarea class="form-control" id="contactmessage"name="message" maxlength="1500" rows="10"  data-rule="required" data-msg="Veuillez remplir cette partie"></textarea>
					<div class="validate"></div>
				  </div>
				  <div class="mb-3">
					<div class="loading">Chargement</div>
					<div id ="message"class="error-message"></div>
					<div class="sent-message">Ton message a été envoyé, merci</div>
				  </div>
				  <div class="text-center"><button type="submit">Envoyer</button></div>
				</form>
			  </div>

			</div>

		  </div>
		</section><!-- End Contact Section -->

	  </main><!-- End #main -->

	 <!DOCTYPE php>
<html lang="fr">


	  <!-- =======================================================
	  * Template Name: Arsha - v2.2.0
	  * Template URL: https://bootstrapmade.com/arsha-free-bootstrap-html-template-corporate/
	  * Author: BootstrapMade.com
	  * License: https://bootstrapmade.com/license/
	  ======================================================== -->

	<body>
	 <!-- ======= Footer ======= -->
		  <footer id="footer" >

			<div class="footer-newsletter" id="discord">
			  <div class="container">
				<div class="row justify-content-center">
				  <div class="col-lg-6">
					<h4>Rejoindre notre discord</h4>
					<a href = "https://discord.io/vliferp"  target="_blank" class="join-discord">Discord vLife RP</a>
				  </div>
				</div>
			  </div>
			</div>

			<div class="footer-top">
			  <div class="container">
				<div class="row">
				  <div class="col-lg-5 col-md-6 footer-contact">
					<img src="https://cdn.vliferoleplay.fr/logo/logo_white.svg" alt="vLife RP" style="width: 110px;padding-bottom: 10px;">
					<p>
					  Serveur de jeu GTA V PC axé sur les<br> services de secours français. 
					</p><br>
					<a class="copyrighted-badge" title="Copyrighted.com Registered &amp; Protected" target="_blank" href="https://www.copyrighted.com/website/qOQZ9XGBfscFCNFp"><img alt="Copyrighted.com Registered &amp; Protected" border="0" width="125" height="25" srcset="https://static.copyrighted.com/badges/125x25/01_2_2x.png 2x" src="https://static.copyrighted.com/badges/125x25/01_2.png" /></a><script src="https://static.copyrighted.com/badges/helper.js"></script>

				  </div>

				  <div class="col-lg-4 col-md-7 footer-links">
					<h4>Liens Utiles</h4>
					<ul>
						<li><i class="fal fa-thermometer-three-quarters  fa-fw" style="margin-right: 10px;"></i><a href="https://status.vliferoleplay.fr/" target="_blank"> Statut des services</a></li>
						<li><i class="far fa-handshake  fa-fw" style="margin-right: 10px;"></i><a href="http://vliferoleplay.fr/partenaire.php">Partenaire</a></li>
						<li><i style="margin: 0px 7px 0px 2px;" class="fal fa-file-exclamation fa-fw"></i><a href="http://vliferoleplay.fr/mentions.php">Mentions légales</a></li>
					</ul>
				  </div>

				  <div class="col-lg-3 col-md-6 footer-links">
					<h4>Nos réseaux sociaux</h4>
					<p>Vous pouvez nous suivre via nos réseaux sociaux pour toujours rester informé.</p>
					<div class="social-links mt-3">
					  <a href="https://twitter.com/vLifeRoleplay" target="_blank" class="twitter"><i class="fab fa-twitter"></i></a>
					  <a href="https://www.youtube.com/channel/UCGIaj2gVvI2P49KcdKPHUJQ" target="_blank" class="youtube"><i class="fab fa-youtube"></i></a>
					  <a href="https://www.instagram.com/vliferoleplay/" target="_blank" class="instagram"><i class="fab fa-instagram"></i></a>
					  <a href="https://www.twitch.tv/vliferoleplay" target="_blank" class="twitch"><i class="fab fa-twitch"></i></a>
					  <a href="https://www.tiktok.com/@vliferoleplay" target="_blank" class="tiktok"><!--<i class="fab fa-tiktok"></i>--><i class="">
					  <svg viewBox="-32 0 512 512" xmlns="http://www.w3.org/2000/svg" height="15pt" width="15pt" style="margin-bottom: 5px;fill: white;"><path d="m432.734375 112.464844c-53.742187 0-97.464844-43.722656-97.464844-97.464844 0-8.285156-6.71875-15-15-15h-80.335937c-8.285156 0-15 6.714844-15 15v329.367188c0 31.59375-25.703125 57.296874-57.300782 57.296874-31.59375 0-57.296874-25.703124-57.296874-57.296874 0-31.597657 25.703124-57.300782 57.296874-57.300782 8.285157 0 15-6.714844 15-15v-80.335937c0-8.28125-6.714843-15-15-15-92.433593 0-167.632812 75.203125-167.632812 167.636719 0 92.433593 75.199219 167.632812 167.632812 167.632812 92.433594 0 167.636719-75.199219 167.636719-167.632812v-145.792969c29.855469 15.917969 63.074219 24.226562 97.464844 24.226562 8.285156 0 15-6.714843 15-15v-80.335937c0-8.28125-6.714844-15-15-15zm-15 79.714844c-32.023437-2.664063-62.433594-13.851563-88.707031-32.75-4.566406-3.289063-10.589844-3.742188-15.601563-1.171876-5.007812 2.5625-8.15625 7.71875-8.15625 13.347657v172.761719c0 75.890624-61.746093 137.632812-137.636719 137.632812-75.890624 0-137.632812-61.742188-137.632812-137.632812 0-70.824219 53.773438-129.328126 122.632812-136.824219v50.8125c-41.015624 7.132812-72.296874 42.984375-72.296874 86.011719 0 48.136718 39.160156 87.300781 87.296874 87.300781 48.140626 0 87.300782-39.164063 87.300782-87.300781v-314.367188h51.210937c6.871094 58.320312 53.269531 104.71875 111.589844 111.589844zm0 0"></path></svg>
					  </i></a>
					</div>
				  </div>
				
				</div>
			  </div>
			</div>
		  </footer><!-- End Footer -->
	</body>
</html>
	<!-- Button Up -->
	  <a href="#" class="back-to-top"><i class="fal fa-arrow-up"></i></a>
	<!-- Alert Cookie -->
	<div class="alert text-center cookiealert" role="alert">
    <b>Aimez-vous les cookies?</b> &#x1F36A; Ce site utilise des cookies pour vous offrir le meilleur service. En poursuivant votre navigation, vous acceptez l’utilisation des cookies. <a href="https://www.vliferoleplay.fr/mentions.php#cookie" target="_blank">En savoir plus</a>
    <button type="button" class="btn btn-primary btn-sm acceptcookies">
        J'accepte
    </button>		

	  <!-- Include cookiealert script -->
	  <script src="assets/js/cookiealert.js"></script>
	  <!-- Vendor JS Files  -->
	  <script src="assets/vendor/font-awesome/js/all.js" data-auto-replace-svg="nest"></script>
	  <script src="assets/vendor/jquery/jquery.min.js"></script>
	  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
	  <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
	  <script src="assets/vendor/php-email-form/validate.js"></script>
	  <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
	  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
	  <script src="assets/vendor/venobox/venobox.min.js"></script>
	  <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>
	  <script src="assets/vendor/aos/aos.js"></script>

	  <!-- Template Main JS File -->
	  <script src="assets/js/main.js"></script>
	  <script>$( document ).ready(function() {
	  
var substr = ['/assets/img/cta-bg.webp', 'https://cdn.discordapp.com/attachments/570361808452321320/1049448666345259038/20221205230105_1.png', 'https://cdn.discordapp.com/attachments/570361808452321320/1056707104024567858/20221225233645_1.jpg','https://cdn.discordapp.com/attachments/570361808452321320/1041669321899900999/20221114111520_1.jpg','https://cdn.discordapp.com/attachments/570361808452321320/1040392669723119716/20221110232651_1.jpg','https://cdn.discordapp.com/attachments/570361808452321320/1040345004419325995/20221110192400_1.jpg']
var time = 5000;

function LoopForever() {
	var i;
	for (i = 0; i < substr.length; ++i) {
		task(i)
	}
	  
	function task(i) {
	  setTimeout(function() {
	      $('.hero').delay(1000*i).css("background", 'linear-gradient(rgba(40, 58, 90, 0.9), rgba(40, 58, 90, 0.9)), url("'+substr[i]+'") fixed center center');
	  }, time * i);
	}  
  
  
}
LoopForever()
var interval = self.setInterval(function(){LoopForever()},time * substr.length);
	  
	  
	 $('a.tip').tooltip();
	/*	$('form').submit(function (event) {
    event.preventDefault();
    if ($(this)[0].checkValidity() === false) {
        event.stopPropagation();
    } else {
$.ajax({
			   type: "POST",
			   url: 'forms/form-process.php',
			   data: form.serialize(), // serializes the form's elements.
			   success: function(data)
			   {
				   alert(data);
				   //alert(data); // show response from the php script.
				   //$('.fetched_data').html(data);
				   //$('.toggle').hide();
			   }
			 });

});*/
	  
	  
	  });
	  
	  
	  </script>
	</body>

</html>