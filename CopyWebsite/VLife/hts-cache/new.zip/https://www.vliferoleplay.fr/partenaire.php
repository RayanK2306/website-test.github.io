<!DOCTYPE html>
<html lang="fr">

		<head>
			<meta charset="utf-8">
			<meta content="width=device-width, initial-scale=1.0" name="viewport">

			<title>Partenaire</title>
			<meta content="" name="description">
			<meta content="" name="keywords">
			<meta property="og:locale" content="fr_FR">
<meta property="og:type" content="website">
<meta property="og:title" content="Partenaire - vLife RP">
<meta property="og:description" content="Serveur de jeu GTA V PC axé sur les
services de secours français.">
<meta property="og:url" content="http://vliferoleplay.fr/partenaire.php">
<meta property="og:site_name" content="vLife Roleplay">
<meta property="og:image" content="https://cdn.vliferoleplay.fr/logo/favicon.png">
			<!-- Favicons -->
			<link rel="apple-touch-icon" sizes="180x180" href="https://www.vliferoleplay.fr/assets/img/favicon/apple-touch-icon.png">
			<link rel="icon" type="image/png" sizes="32x32" href="https://www.vliferoleplay.fr/assets/img/favicon/favicon-32x32.png">
			<link rel="icon" type="image/png" sizes="16x16" href="https://www.vliferoleplay.fr/assets/img/favicon/favicon-16x16.png">
			<link rel="manifest" href="https://www.vliferoleplay.fr/assets/img/favicon/site.webmanifest">
			<link rel="mask-icon" href="https://www.vliferoleplay.fr/assets/img/favicon/safari-pinned-tab.svg" color="#5bbad5">
			<link rel="shortcut icon" href="https://www.vliferoleplay.fr/assets/img/favicon/favicon.ico">
			<meta name="msapplication-TileColor" content="#2b5797">
			<meta name="msapplication-config" content="https://www.vliferoleplay.fr/assets/img/favicon/browserconfig.xml">
			<meta name="theme-color" content="#ffffff">
			
			  <!-- Google Fonts -->
		  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Jost:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

		  <!-- Vendor CSS Files 
		  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
		  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
		  -->
		  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
		  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
		  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
		  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
		  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
		  <link rel="stylesheet" href="assets/vendor/font-awesome/css/all.min.css"> <!-- Font Awesome 5.12.1 Pro -->

		  <!-- Template Main CSS File -->
		  <link href="assets/css/style.css" rel="stylesheet">
		  <link rel="stylesheet" href="assets/css/cookiealert.css">
		 
			

		  <!-- =======================================================
		  * Template Name: Arsha - v2.2.0
		  * Template URL: https://bootstrapmade.com/arsha-free-bootstrap-html-template-corporate/
		  * Author: BootstrapMade.com
		  * License: https://bootstrapmade.com/license/
		  ======================================================== -->
		</head>

<body>
	 <div id="preloader"></div>
	 <!-- ======= Header ======= -->
	 <!DOCTYPE html>
  <!-- =======================================================
		  * Template Name: Arsha - v2.2.0
		  * Template URL: https://bootstrapmade.com/arsha-free-bootstrap-html-template-corporate/
		  * Author: BootstrapMade.com
		  * License: https://bootstrapmade.com/license/
		  ======================================================== -->
		  
<html lang="fr">
	<body>
	<!-- ======= Header ======= -->
		   <header id="header" class="fixed-top header-inner-pages">
<div class="container d-flex align-items-center">
		<a href="http://vliferoleplay.fr/" class="mr-auto">
		<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 224.56 98.54"><defs><style>.cls-1{fill:#fff;}</style></defs><g id="Calque_2" data-name="Calque 2"><g id="Calque_1-2" data-name="Calque 1"><polygon class="cls-1" points="61.81 0 61.81 58.08 102.66 58.08 102.66 46.8 75.35 46.8 75.35 0 61.81 0"/><rect class="cls-1" x="108.94" width="14.26" height="58.08"/><path class="cls-1" d="M129.48,0H172.8V12.56H143.41v9.59h27.08V34H143.41v24H129.48Z"/><polygon class="cls-1" points="179.08 0 222.41 0 222.41 12.56 193.01 12.56 193.01 22.15 220.09 22.15 220.09 34.02 193.01 34.02 193.01 45.64 222.41 45.64 222.41 58.08 179.08 58.08 179.08 0"/><path class="cls-1" d="M66,84.44a13.74,13.74,0,0,1-1.1,5.49,14.14,14.14,0,0,1-3,4.47,14.37,14.37,0,0,1-4.49,3,13.92,13.92,0,0,1-10.94,0,14.37,14.37,0,0,1-4.49-3,14.14,14.14,0,0,1-3-4.47,14.28,14.28,0,0,1,0-11,14.24,14.24,0,0,1,7.52-7.51,14.15,14.15,0,0,1,10.94,0,14.24,14.24,0,0,1,7.52,7.51A13.75,13.75,0,0,1,66,84.44Zm-4.38,0a9.94,9.94,0,0,0-2.86-7,10,10,0,0,0-3.09-2.14,9.24,9.24,0,0,0-7.52,0,10,10,0,0,0-5.18,5.28,9.77,9.77,0,0,0-.77,3.85,9.63,9.63,0,0,0,.77,3.8A10.34,10.34,0,0,0,45,91.41a10,10,0,0,0,3.09,2.15,9.31,9.31,0,0,0,7.55,0,9.87,9.87,0,0,0,3.08-2.15,10.47,10.47,0,0,0,2.07-3.17A9.63,9.63,0,0,0,61.58,84.44Z"/><path class="cls-1" d="M90.09,98H72.42V70.83h4.39v23H90.09Z"/><path class="cls-1" d="M143.91,79.59a8.72,8.72,0,0,1-.68,3.41,8.88,8.88,0,0,1-1.85,2.79,8.74,8.74,0,0,1-2.76,1.89,8.11,8.11,0,0,1-3.35.7h-8.6v9.69h-4.35V70.8h13a8.11,8.11,0,0,1,3.35.7,8.75,8.75,0,0,1,4.61,4.68A8.72,8.72,0,0,1,143.91,79.59Zm-4.42,0a4.43,4.43,0,0,0-.36-1.76,4.38,4.38,0,0,0-1-1.47,4.46,4.46,0,0,0-1.42-1A4.13,4.13,0,0,0,135,75h-8.33V84.2h8.26a4.47,4.47,0,0,0,1.79-.36,4.28,4.28,0,0,0,1.44-1,4.55,4.55,0,0,0,1-1.46A4.5,4.5,0,0,0,139.49,79.59Z"/><path class="cls-1" d="M169.68,98H149.35V70.83h4.39v23h15.94Z"/><path class="cls-1" d="M200,98h-4.66l-3.19-7.2H179.75l-3.2,7.2h-4.66L184,70.83h3.95Zm-9.72-11.39-4.36-9.79-4.31,9.79Z"/><path class="cls-1" d="M224.56,70.83,213.1,86.54V98h-4.32V86.54L197.29,70.83h5.27l8.36,11.46,8.44-11.46Z"/><path class="cls-1" d="M26.76,87a8.21,8.21,0,0,0,3.55-3.14,9.42,9.42,0,0,0,1-2.19,8.21,8.21,0,0,0,.36-2.4A8.33,8.33,0,0,0,31,76a8.62,8.62,0,0,0-1.77-2.69,8.48,8.48,0,0,0-2.63-1.84,7.8,7.8,0,0,0-3.21-.68H10.17v5.94h4.35V75h8.54a4,4,0,0,1,1.61.34,4.35,4.35,0,0,1,1.34.93,4.29,4.29,0,0,1,.9,1.37,4.24,4.24,0,0,1,.33,1.66A4.34,4.34,0,0,1,26.91,81a3.89,3.89,0,0,1-.9,1.37,4.3,4.3,0,0,1-1.36.92,4.2,4.2,0,0,1-1.66.33H14.52V79.17H10.17v18.9h4.35V87.77h7.55L28.87,98H34Z"/><polygon class="cls-1" points="100.22 86.37 114.81 86.37 114.81 82.19 100.22 82.19 100.22 79.17 95.87 79.17 95.87 98.03 116.54 98.03 116.54 93.85 100.22 93.85 100.22 86.37"/><polygon class="cls-1" points="95.87 70.8 95.87 76.74 100.22 76.74 100.22 74.98 116.54 74.98 116.54 70.8 95.87 70.8"/><path class="cls-1" d="M15.29,4.9c-.63-1.79-1.21-3.46-1.72-4.9H0C.45,1.4,1,3.06,1.56,4.9Z"/><path class="cls-1" d="M38.4,0l-12,36.61L16.76,9.09H2.89C8.39,26.4,17.16,54,18.47,58.08H34.32L52.87,0Z"/></g></g></svg>
		<!--<img src="https://cdn.vliferoleplay.fr/logo/logo_white.svg" alt="vLife RP" style="width: 110px;">-->
		</a>
		  <!--<h1 class="logo mr-auto"><a href="http://vliferoleplay.fr/index.php">vLife RP</a></h1>-->
		  <!-- Uncomment below if you prefer to use an image logo -->
		  <!-- <a href="index.html" class="logo mr-auto"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

		  
		  
		  <nav class="nav-menu d-none d-lg-block" id="nav">
			<ul>
			  <li class="nav"><a href="http://vliferoleplay.fr/">Accueil</a></li>
			  
			  
			   <li class="dropdown"><a href="#"  class="dropdown-toggle" id="recrutement" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span>Recrutement</span> </a>
            <ul class="dropdown-menu" class="color:black" aria-labelledby="recrutement">
              <li><a class="dropdown-item" href="http://vliferoleplay.fr/recrutement"><i class="fas fa-file-signature fa-fw"></i> Rejoindre le serveur</a></li>
              <li><a class="dropdown-item" href ="#" data-toggle="modal" data-target="#Pole"><i class="fas fa-tools fa-fw"></i> Rejoindre le pôle technique</a></li>
              <li><a class="dropdown-item" href ="#" data-toggle="modal" data-target="#Fonction"><i class="fas fa-file-search fa-fw"></i> Fonctionnement</a></li>
              <li><a class="dropdown-item" class="dropdown-item" href ="#" data-toggle="modal" data-target="#FAQ"><i class="fas fa-question fa-fw"></i> Foire aux questions</a></li>
            </ul>
          </li>
		  
		  
		  <li class="dropdown"><a href="#"  class="dropdown-toggle" id="communication" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span>Communication</span> </a>
            <ul class="dropdown-menu" class="color:black" aria-labelledby="communication">
              <li><a class="dropdown-item" href="https://www.twitch.tv/vliferoleplay" target="_blank"><i class="fab fa-twitch fa-fw"></i> Twitch</a></li>
              <li><a class="dropdown-item" href="http://vliferoleplay.fr/#portfolio"><i class="fas fa-image fa-fw"></i> Portfolio</a></li>
              <li><a class="dropdown-item" href ="https://twitter.com/vLifeRoleplay"  target="_blank"><i class="fab fa-twitter fa-fw"></i> Twitter</a></li>
			  <li><a  class="dropdown-item" href="http://vliferoleplay.fr/partenaire.php"><i class="fas fa-handshake fa-fw"></i> Partenaires</a></li>
            </ul>
          </li>
		  
		   <li class="dropdown"><a href="#"  class="dropdown-toggle" id="communaute" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span>Communauté</span></a>
            <ul class="dropdown-menu" class="color:black" aria-labelledby="communaute">
              <li><a class="dropdown-item" href="https://discord.gg/vliferp" target="_blank"><i class="fab fa-discord fa-fw"></i> Discord</a></li>
              <li><a class="dropdown-item"  href="http://vliferoleplay.fr/#team"><i class="fas fa-users-cog fa-fw"></i> Team</a></li>
		 <li><a class="dropdown-item" href="https://dons.vliferoleplay.fr/"><i class="fab fa-paypal fa-fw"></i>Donations</a></li>	
	      			  
            </ul>
          </li>  
			  <!--<li><a href="http://vliferoleplay.fr/partenaire.php" name="partenaire.php">Partenaire</a></li>-->
			  <!--<li><a href="http://vliferoleplay.fr/#contact">Contact</a></li>-->
			  <li class="nav"><a href="https://boutique.vliferoleplay.fr">Boutique</a></li>
			</ul>
		  </nav><!-- .nav-menu -->
			<a href="https://www.vliferoleplay.fr/?action=login" class="get-started-btn scrollto">Connexion</a>
		</div>
	  </header><!-- End Header -->

	  <div class="modal fade faq" id="FAQ" tabindex="-1" role="dialog" aria-labelledby="FAQLabel" aria-hidden="false">
				  <div class="modal-dialog" role="document">
					<div class="modal-content">
					  <div class="modal-header">
						<h5 class="modal-title" id="FAQLabel">Foire aux questions</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						  <span aria-hidden="true">&times;</span>
						</button>
					  </div>
					  <div class="modal-body">
						<div class="section-title">
			  <h2 style="color:black;">Les questions souvent posées</h2>
			  <p>Vous trouverez ici plusieurs réponses à vos questions concernant le recrutement. Si malgré tout vous nécessitez une assistance, merci de passer par le discord, ou à défaut le formulaire de contact.</p>
			</div>

			<div class="faq-list" style="padding:0px;">
			  <ul>
				<li data-aos="fade-up" data-aos-delay="100">
				  <i class="fal fa-question-circle icon-help"></i> <a data-toggle="collapse" class="collapse" href="#faq-list-1"> Quel est le délai de réponse suite à une candidature ? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
				  <div id="faq-list-1" class="collapse show" data-parent=".faq-list">
					<p>
					  Il est de 48h, sauf période festive où il peut être plus long. 
					</p>
				  </div>
				</li>

				<li data-aos="fade-up" data-aos-delay="200">
				  <i class="fal fa-question-circle icon-help"></i> <a data-toggle="collapse" href="#faq-list-2" class="collapsed">Quel est l'âge minimum d'entrée ?<i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
				  <div id="faq-list-2" class="collapse" data-parent=".faq-list">
					<p>
					  L'âge minimal d'entrée pour le poste de civil est de 15 ans. 
					  Il est de 16 ans pour les services de secours, il n'y a aucune dérogation possible.
					</p>
				  </div>
				</li>

				<li data-aos="fade-up" data-aos-delay="300">
				  <i class="fal fa-question-circle icon-help"></i> <a data-toggle="collapse" href="#faq-list-3" class="collapsed"> L'expérience RP est-elle un critère d'évaluation important ?<i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
				  <div id="faq-list-3" class="collapse" data-parent=".faq-list">
					<p>
					  Non. Même si vous n'avez pas d'expérience, cela ne pénalisera en rien votre candidature.
					</p>
				  </div>
				</li>

				<li data-aos="fade-up" data-aos-delay="400">
				  <i class="fal fa-question-circle icon-help"></i> <a data-toggle="collapse" href="#faq-list-4" class="collapsed">Si je suis professionnel du métier, serais-je favorisé ? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
				  <div id="faq-list-4" class="collapse" data-parent=".faq-list">
					<p>
					  En aucun cas, nous privilégions l'équité entre les candidats, qu'importe votre statut, âge ou métier.
					</p>
				  </div>
				</li>

				<li data-aos="fade-up" data-aos-delay="500">
				  <i class="fal fa-question-circle icon-help"></i> <a data-toggle="collapse" href="#faq-list-5" class="collapsed">J'ai postulé pour un service de secours et je souhaiterais devenir Civil, en attendant d'avoir ma réponse, est-ce possible ? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
				  <div id="faq-list-5" class="collapse" data-parent=".faq-list">
					<p>
					  Cela n'est en aucun cas possible. Veuillez prendre votre mal en patience.
					</p>
				  </div>
				</li>
				
				<li data-aos="fade-up" data-aos-delay="600">
				  <i class="fal fa-question-circle icon-help"></i> <a data-toggle="collapse" href="#faq-list-6" class="collapsed">Si je suis refusé à l'écris ou à l'oral que dois-je faire ? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
				  <div id="faq-list-6" class="collapse" data-parent=".faq-list">
					<p>
					  En dehors d'un refus définitif ou d'un bannissement vous avez la possibilité de déposer une seconde candidature deux semaines après la date de votre refus. 
					  Le deuxième refus sera cependant définitif
					</p>
				  </div>
				</li>

			  </ul>
			</div>
					  </div>
					  <div class="modal-footer">
						<button type="button" class="btn btn-primary" data-dismiss="modal">Fermer</button>
					  </div>
					</div>
				  </div>
				</div>
			<div class="modal fade" id="Fonction" tabindex="-1" role="dialog" aria-labelledby="FonctionLabel" aria-hidden="false">
				<div class="modal-dialog" role="document">
					<div class="modal-content">
					  <div class="modal-header">
						<h5 class="modal-title" id="FonctionLabel">Fonctionnement</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						  <span aria-hidden="true">&times;</span>
						</button>
					  </div>
					<div class="modal-body">
						<div class="section-title">
						  <h2 style="color:black;">Fonctionnement du serveur</h2>
						  <p>Vous trouverez ici le fonctionnement du serveur se trouvant à la limite du life et du totalement scénarisé.</p>
						</div>
						<div  style="padding:0px;">
						<p style="white-space:pre-line;overflow:auto;">Nous fonctionnons par session de jeu définie, le roleplay n'est pas constant pour pouvoir tous se réunir aux heures de jeu. 
						Chaque session débute à 21h00 et n'a pas d'heure de fin (jusqu'à que l'ensemble des joueurs déconnectent). Ces sessions RP sont réalisées tous les jours.
						Les actions doivent impliquer les services de secours, de temps en temps encadré par des plus anciens. On parle ici d'accompagnement pour un jeune joueur sur notre serveur, qu'il ne soit pas perdu. Cela demande aussi de la coordination, pour que chaque intervention soient réalisées au bon moment, et que tout le monde en profite (pas de temps mort)
						Vu que les actions sont créées par les civils, elles peuvent être non spontanées (montée de toute pièce), c'est de l'action passive.
						Néanmoins, les services de secours ne sont pas au courant de ce qui se déroule, et l'ensemble des manœuvres faites par les secours ne sont pas connues ni préparées, tout doit être géré par le pompier/policier/médecin qui doit mettre en pratique ce qu'il a pu apprendre en formation.
						À savoir que la vie civile perdure constamment, chaque interventions peuvent avoir un lien entre elles.</p>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-primary" data-dismiss="modal">Fermer</button>
					</div>
					</div>
				</div>
			</div>
			
			
			<div class="modal fade" id="Pole" tabindex="-1" role="dialog" aria-labelledby="polet" aria-hidden="false">
				<div class="modal-dialog" role="document">
					<div class="modal-content">
					  <div class="modal-header">
						<h5 class="modal-title" id="polet">Rejoindre le pôle technique</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						  <span aria-hidden="true">&times;</span>
						</button>
					  </div>
					<div class="modal-body">
						<div class="section-title">
						  <h2 style="color:black;">Rejoindre le pôle technique</h2>
						  <p>Si vous souhaitez rejoindre notre pôle technique, merci de suivre les indications suivantes :</p>
						</div>
						<div  style="padding:0px;">
						<a style="cursor: zoom-in;" href="https://cdn.discordapp.com/attachments/568461477405655081/827879638277554203/2021-03-28_5.png" data-gall="Gall" class="venobox preview-link" title="Agrandir"><img loading="lazy" class="img-fluid" src="https://cdn.discordapp.com/attachments/568461477405655081/827879638277554203/2021-03-28_5.png" alt="Rejoindre pôle technique"></a>
						<p style="white-space:pre-line;overflow:auto;">
						Vous pouvez également contacter tout membre de l'<img loading="lazy" class="img-fluid" src="https://cdn.discordapp.com/attachments/432167703453761537/912613854423420928/unknown.png" width="20%" alt="état-major"></img> via notre <a href="https://discord.gg/vliferp" target="_blank"><i style="font-size:20px;" class="fab fa-discord"></i></a>
						</p>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-primary" data-dismiss="modal">Fermer</button>
					</div>
					</div>
				</div>
			</div>
	</body>
</html>


  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <ol>
          <li><a href="index.php">Accueil</a></li>
          <li>Partenaire</li>
        </ol>
        <h3>Partenaire de vLife RP</h3>

      </div>
    </section><!-- End Breadcrumbs -->

    <section class="inner-page contact" id="partenaire">
      <div class="container php-email-form" data-aos="fade-up">
		<img class="img-fluid" src="https://cdn.discordapp.com/attachments/725378398523883672/992778302462898226/120120.png" alt="Brocloud" ><br><br>
		<p>Notre partenaire <b>Brocloud</b> est un hébergeur digital qui sécurise vos données, et vous accompagne.
Proposant un grand nombre de solutions d’hébergement Web, Cloud, Télécom et Jeux, vous avez aussi la possibilité de faire réaliser un site web, ou encore un logiciel Windows grâce à <b>Brocloud</b>.
Ce partenaire soutient <b>vLife Roleplay</b> depuis ses débuts, et assure aujourd’hui encore la maintenance du serveur d’applications sur lequel sont hébergées les données réseau des logiciels de la BSPP et du SAMU, en plus du nom de domaine <b>vliferoleplay.fr</b>.
Cet hébergeur pour tous se consacre aussi et surtout à l’accompagnement des clients, afin qu’ils réussissent au mieux leur projet, et ce, dans les meilleures conditions possibles (services, performance, support client).

		</p>
			<div class="social">
					  <a href="https://twitter.com/brocloud_fr" target="_blank"><i class="fab fa-twitter"></i></a>
					  <a href="https://www.youtube.com/channel/UCfhh5nxvXBcrWIuyYPg4B3Q" target="_blank"><i class="fab fa-youtube"></i></a>
					  <a href="https://discord.gg/EDK6RET" target="_blank"><i class="fab fa-discord"></i></a>
					  <a href ="https://brocloud.fr/" target="_blank"><i class="fal fa-link"></i></a>
			</div>
      </div>
    </section>

  </main><!-- End #main -->
	<!DOCTYPE php>
<html lang="fr">


	  <!-- =======================================================
	  * Template Name: Arsha - v2.2.0
	  * Template URL: https://bootstrapmade.com/arsha-free-bootstrap-html-template-corporate/
	  * Author: BootstrapMade.com
	  * License: https://bootstrapmade.com/license/
	  ======================================================== -->

	<body>
	 <!-- ======= Footer ======= -->
		  <footer id="footer" >

			<div class="footer-newsletter" id="discord">
			  <div class="container">
				<div class="row justify-content-center">
				  <div class="col-lg-6">
					<h4>Rejoindre notre discord</h4>
					<a href = "https://discord.io/vliferp"  target="_blank" class="join-discord">Discord vLife RP</a>
				  </div>
				</div>
			  </div>
			</div>

			<div class="footer-top">
			  <div class="container">
				<div class="row">
				  <div class="col-lg-5 col-md-6 footer-contact">
					<img src="https://cdn.vliferoleplay.fr/logo/logo_white.svg" alt="vLife RP" style="width: 110px;padding-bottom: 10px;">
					<p>
					  Serveur de jeu GTA V PC axé sur les<br> services de secours français. 
					</p><br>
					<a class="copyrighted-badge" title="Copyrighted.com Registered &amp; Protected" target="_blank" href="https://www.copyrighted.com/website/qOQZ9XGBfscFCNFp"><img alt="Copyrighted.com Registered &amp; Protected" border="0" width="125" height="25" srcset="https://static.copyrighted.com/badges/125x25/01_2_2x.png 2x" src="https://static.copyrighted.com/badges/125x25/01_2.png" /></a><script src="https://static.copyrighted.com/badges/helper.js"></script>

				  </div>

				  <div class="col-lg-4 col-md-7 footer-links">
					<h4>Liens Utiles</h4>
					<ul>
						<li><i class="fal fa-thermometer-three-quarters  fa-fw" style="margin-right: 10px;"></i><a href="https://status.vliferoleplay.fr/" target="_blank"> Statut des services</a></li>
						<li><i class="far fa-handshake  fa-fw" style="margin-right: 10px;"></i><a href="http://vliferoleplay.fr/partenaire.php">Partenaire</a></li>
						<li><i style="margin: 0px 7px 0px 2px;" class="fal fa-file-exclamation fa-fw"></i><a href="http://vliferoleplay.fr/mentions.php">Mentions légales</a></li>
					</ul>
				  </div>

				  <div class="col-lg-3 col-md-6 footer-links">
					<h4>Nos réseaux sociaux</h4>
					<p>Vous pouvez nous suivre via nos réseaux sociaux pour toujours rester informé.</p>
					<div class="social-links mt-3">
					  <a href="https://twitter.com/vLifeRoleplay" target="_blank" class="twitter"><i class="fab fa-twitter"></i></a>
					  <a href="https://www.youtube.com/channel/UCGIaj2gVvI2P49KcdKPHUJQ" target="_blank" class="youtube"><i class="fab fa-youtube"></i></a>
					  <a href="https://www.instagram.com/vliferoleplay/" target="_blank" class="instagram"><i class="fab fa-instagram"></i></a>
					  <a href="https://www.twitch.tv/vliferoleplay" target="_blank" class="twitch"><i class="fab fa-twitch"></i></a>
					  <a href="https://www.tiktok.com/@vliferoleplay" target="_blank" class="tiktok"><!--<i class="fab fa-tiktok"></i>--><i class="">
					  <svg viewBox="-32 0 512 512" xmlns="http://www.w3.org/2000/svg" height="15pt" width="15pt" style="margin-bottom: 5px;fill: white;"><path d="m432.734375 112.464844c-53.742187 0-97.464844-43.722656-97.464844-97.464844 0-8.285156-6.71875-15-15-15h-80.335937c-8.285156 0-15 6.714844-15 15v329.367188c0 31.59375-25.703125 57.296874-57.300782 57.296874-31.59375 0-57.296874-25.703124-57.296874-57.296874 0-31.597657 25.703124-57.300782 57.296874-57.300782 8.285157 0 15-6.714844 15-15v-80.335937c0-8.28125-6.714843-15-15-15-92.433593 0-167.632812 75.203125-167.632812 167.636719 0 92.433593 75.199219 167.632812 167.632812 167.632812 92.433594 0 167.636719-75.199219 167.636719-167.632812v-145.792969c29.855469 15.917969 63.074219 24.226562 97.464844 24.226562 8.285156 0 15-6.714843 15-15v-80.335937c0-8.28125-6.714844-15-15-15zm-15 79.714844c-32.023437-2.664063-62.433594-13.851563-88.707031-32.75-4.566406-3.289063-10.589844-3.742188-15.601563-1.171876-5.007812 2.5625-8.15625 7.71875-8.15625 13.347657v172.761719c0 75.890624-61.746093 137.632812-137.636719 137.632812-75.890624 0-137.632812-61.742188-137.632812-137.632812 0-70.824219 53.773438-129.328126 122.632812-136.824219v50.8125c-41.015624 7.132812-72.296874 42.984375-72.296874 86.011719 0 48.136718 39.160156 87.300781 87.296874 87.300781 48.140626 0 87.300782-39.164063 87.300782-87.300781v-314.367188h51.210937c6.871094 58.320312 53.269531 104.71875 111.589844 111.589844zm0 0"></path></svg>
					  </i></a>
					</div>
				  </div>
				
				</div>
			  </div>
			</div>
		  </footer><!-- End Footer -->
	</body>
</html>
  <a href="#" class="back-to-top"><i class="fal fa-arrow-up"></i></a>

  <!-- Alert Cookie -->
	<div class="alert text-center cookiealert" role="alert">
    <b>Aimez-vous les cookies?</b> &#x1F36A; Ce site utilise des cookies pour vous offrir le meilleur service. En poursuivant votre navigation, vous acceptez l’utilisation des cookies. <a href="https://www.vliferoleplay.fr/mentions.php#cookie" target="_blank">En savoir plus</a>
    <button type="button" class="btn btn-primary btn-sm acceptcookies">
        J'accepte
    </button>		

  <!-- Include cookiealert script -->
  <script src="assets/js/cookiealert.js"></script>	
  <!-- Vendor JS Files -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/venobox/venobox.min.js"></script>
  <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
  <script>
	$(document).ready(function() {
	$.each($('#nav').find('li'), function() {
				$(this).toggleClass('active', 
					window.location.pathname.indexOf($(this).find('a').attr('name')) > -1);
				}); 
	});
	</script>

</body>

</html>